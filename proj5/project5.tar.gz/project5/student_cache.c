#include "student_cache.h"


int student_read(address_t addr, student_cache_t *cache, stat_t *stats){
	return 0;
}

int student_write(address_t addr, student_cache_t *cache, stat_t *stats){
	return 0;
}

student_cache_t *allocate_cache(int C, int B, int S, int WP, stat_t* statistics){
	return NULL;
}

void finalize_stats(student_cache_t *cache, stat_t *statistics){

}


